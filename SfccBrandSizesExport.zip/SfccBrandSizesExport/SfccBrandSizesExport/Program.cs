﻿// See https://aka.ms/new-console-template for more information

using System.Xml.Linq;
using System.Xml;

Console.WriteLine("Hello, World!");

/*var productList = File.ReadAllLines("/Users/rochdi/Dev/gwf/SFCC-brandsSizes/Brands.csv")
    .Skip(1)
    .Select(l => l.Split(";")).Select( l => new {Id = l[0],Brand=l[1] });



// Define the XML namespace
XmlNamespaceManager namespaceManager = new XmlNamespaceManager(new NameTable());
namespaceManager.AddNamespace("dw", "http://www.demandware.com/xml/impex/catalog/2006-10-31");

// Create the XML document and root element
XmlDocument xmlDoc = new XmlDocument();
XmlElement rootElement = xmlDoc.CreateElement("catalog", "http://www.demandware.com/xml/impex/catalog/2006-10-31");
rootElement.SetAttribute("catalog-id", "goodwill-master");
xmlDoc.AppendChild(rootElement);

// Loop through the list of products and add them to the XML document
foreach (var product in productList)
{
    // Create the product element with its product ID attribute
    XmlElement productElement = xmlDoc.CreateElement("product", "http://www.demandware.com/xml/impex/catalog/2006-10-31");
    productElement.SetAttribute("product-id", product.Id);

    // Create the brand element and add the brand name as its text
    XmlElement brandElement = xmlDoc.CreateElement("brand", "http://www.demandware.com/xml/impex/catalog/2006-10-31");
    brandElement.InnerText = product.Brand;

    // Add the brand element to the product element
    productElement.AppendChild(brandElement);

    // Add the product element to the root element
    rootElement.AppendChild(productElement);
}

// Save the XML document to a file or a string
xmlDoc.Save("catalog-brands.xml");

*/

//File.ReadAllLines("/Users/rochdi/Dev/gwf/SFCC-brandsSizes/sizes.csv").Skip(1);
var productList = File.ReadAllLines("/Users/rochdi/Dev/gwf/SFCC-brandsSizes/sizes.csv")
    .Skip(1)
    .Select(l => l.Split(";")).Select( l => new {Id = l[0],Size=l[1] });




// Define the XML namespace
XmlNamespaceManager namespaceManager = new XmlNamespaceManager(new NameTable());
namespaceManager.AddNamespace("dw", "http://www.demandware.com/xml/impex/catalog/2006-10-31");

// Create the XML document and root element
XmlDocument xmlDoc = new XmlDocument();
XmlElement rootElement = xmlDoc.CreateElement("catalog", "http://www.demandware.com/xml/impex/catalog/2006-10-31");
rootElement.SetAttribute("catalog-id", "goodwill-master");
xmlDoc.AppendChild(rootElement);

// Loop through the list of products and add them to the XML document
foreach (var product in productList)
{
    // Create the product element with its product ID attribute
    XmlElement productElement = xmlDoc.CreateElement("product", "http://www.demandware.com/xml/impex/catalog/2006-10-31");
    productElement.SetAttribute("product-id", product.Id);

    // Create the custom-attributes element
    XmlElement customAttributesElement = xmlDoc.CreateElement("custom-attributes", "http://www.demandware.com/xml/impex/catalog/2006-10-31");

    // Create the custom-attribute element with its attribute ID and value
    XmlElement customAttributeElement = xmlDoc.CreateElement("custom-attribute", "http://www.demandware.com/xml/impex/catalog/2006-10-31");
    customAttributeElement.SetAttribute("attribute-id", "size");
    customAttributeElement.InnerText = product.Size;

    // Add the custom-attribute element to the custom-attributes element
    customAttributesElement.AppendChild(customAttributeElement);

    // Add the custom-attributes element to the product element
    productElement.AppendChild(customAttributesElement);

    // Add the product element to the root element
    rootElement.AppendChild(productElement);
}

// Save the XML document to a file or a string
xmlDoc.Save("catalog-size.xml");

